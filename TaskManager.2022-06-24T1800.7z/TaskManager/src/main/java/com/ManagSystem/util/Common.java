package com.ManagSystem.util;

import java.util.function.BiFunction;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

public class Common {

	/*
	 * NULL,空文字チェック
	 * @param  チェック項目
	 * @return チェック結果
	 */
	public static boolean isEmpty(Object value) {
		if(value == null || value.toString().equals("")) {
			return true;
		} else {
			return false;
		}

	}
	
	/*
	 * 条件式の作成
	 * @param
	 * @return
	 */
	public static <T> Specification<T> spec(Class<T> entity, BiFunction<CriteriaBuilder, Root<T>, Predicate> predicate) {
		return spec(predicate);
	}
	
	/*
	 * 条件式の作成
	 * @param
	 * @return
	 */
	public static <T> Specification<T> spec(BiFunction<CriteriaBuilder, Root<T>, Predicate> predicate) {
		return new Specification<T> () {
			private static final long serialVersionUID = 1L;
		
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return predicate.apply(cb, root);
			}
		};
	}
}

