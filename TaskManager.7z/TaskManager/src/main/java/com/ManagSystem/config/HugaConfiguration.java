package com.ManagSystem.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.ManagSystem.service.TaskService;

@EnableConfigurationProperties({TaskService.class})
public class HugaConfiguration {

}
