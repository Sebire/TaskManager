package com.ManagSystem.form;

import lombok.Data;

@Data
public class TaskSearchForm {
	
	private String taskTitle;
	
	private String taskKana;
	
	private String taskMember;
	
	private String taskMemberKana;
	
	private String taskStartDate;
	
	private String taskFinishDate;
	

}
