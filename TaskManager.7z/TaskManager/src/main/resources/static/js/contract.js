$(document).ready(function(){
	/*
	$.extend( $.fn.dataTable.defaults, {
		language: {
			url: "../../assets/plugins/datatables.net/datatables-japanese.json",
		}
	});
	*/
	// 入力項目フォーカス時のEnterキーによるSubmitを無効
	$('input').keypress(function(ev) {
		if ((ev.which && ev.which === 13) || (ev.keyCode && ev.keyCode === 13)) {
			return false;
		} else {
			return true;
		}
	});
	
	$("#contract-list-table").DataTable({
		// 検索機能 無効
		searching: false,
		"bInfo" : 		false,
		language : {
            "zeroRecords": " ",
			url: "../../assets/plugins/datatables.net/datatables-japanese.json",             
        },
	});
	var selectedProposition =null;
	var selectedEngineers = null;
	var selectedClient = null;
	//各テーブルを未表示にする
	$('#engineerModalTableThead').hide();
	$('#clientModalTableThead').hide();
	$('#propositionModalTableThead').hide();
	$("#apTaxSection").change(function(){
	 	getTax();	
	})
	//データテーブルヘッダーが列と整列していないエラーを解決 
	onShowModalDestroyOldAndInitNewDatatable('#getPropositionModal','#propositionModalTable');	  		
	table=$("#propositionModalTable").DataTable();
  	$('#propositionModalTable tbody').on('click', 'input[type="checkbox"]', function () {
		selectedProposition = null;
  		  //一つチェクスボックスだけチェックできるようにする
  		$('input[type="checkbox"]').not(this).prop('checked', false); 	  	
  		  //チェックしたデータをとる
  		 if(this.checked) {
  			var tr = $(this).closest("tr");
	  	  	selectedProposition = $("#propositionModalTable").DataTable().rows(tr).data()[0];	
		 }
 	});
	//子画面の検索
	$('#searchPropositionBtn').click(function() {
	    $('#propositionModalTableThead').show();
		searchProposition();	
	});
	$('#searchEngineerBtn').click(function() {
		$('#engineerModalTableThead').show();
	    searchEngineer();	
	});
	
	$('#searchClientBtn').click(function() {
		$('#clientModalTableThead').show();
	    searchClient();	
	});
	//小画面キャンセルボタンのクリック処理
	$('.cancelModalBtn').click(function() {
		selectedProposition = null;
		selectedEngineers 	= null;
		selectedClient 		= null;
		$('#engineerModalTableThead').hide();
		$('#clientModalTableThead').hide();
		$('#propositionModalTableThead').hide();
	});
	//エンジニア検索小画面の選択ボタンをクリック処理
	$('#selectEngineerBtn').click(function(e) {
		if (selectedEngineers != null && selectedEngineers[0] != null){ 
	    	e.preventDefault(); 
	  		$('#getEngineerModal').modal('hide');
			engineersTable =$("#engineerListTable").DataTable();
			engineersTable.clear();
			$.each(selectedEngineers, function(index, row){
				engineersTable.row.add( [
		            index +1,
		            row[2],
					row[3],
					row[4],
					row[5]
		     	] ).draw(false);
			});			
			$('#engineerModalTableThead').hide();
		} else {
			$("#error").html("開発者を選択してください。");
	    	$('#myModal').css('max-height', '50vh');
    	    $('#myModal').modal("show");
		}
		selectedEngineers= null;
	})
	 //取引先検索小画面の選択ボタンをクリック処理
	$('#selectClientBtn').click(function(e) {
		if (selectedClient != null){ 
	    	e.preventDefault(); 
	  		$('#getClientModal').modal('hide');
			autoFillClientInfo(selectedClient);
			$('#clientModalTableThead').hide();
		} else {
			$("#error").html("顧客を選択してください。");
	    	$('#myModal').css('max-height', '50vh');
    	    $('#myModal').modal("show");
		}
		selectedEngineers= null;
	}) 		
	//案件検索小画面の選択ボタンをクリック処理	
  	$('#selectPropositionBtn').click(function(e) {
	    if (selectedProposition != null){ 
	    	e.preventDefault(); 
			$('#propositionModalTableThead').hide();
	  		$('#getPropositionModal').modal('hide');
	  		$("#propositionNo").val(selectedProposition[2]).text(selectedProposition[2]);
			$("#propositionName").val(selectedProposition[3]).text(selectedProposition[3]);
			$("#contractStartDate").val(selectedProposition[4]).text(selectedProposition[4]);
			$("#contractEndDate").val(selectedProposition[5]).text(selectedProposition[5]);
			$("#propositionContent").val(selectedProposition[6]).text(selectedProposition[6]); 
			$("#commercialDistribution").val(selectedProposition[7]).text(selectedProposition[7]);
	    } else {
	    	//何もチェックしない場合：
	    	$("#error").html("案件を選択してください。");
	    	$('#myModal').css('max-height', '50vh');
    	    $('#myModal').modal("show");
	    }
	    selectedProposition=null;
	});	
	table=$("#engineerModalTable").DataTable();
	onShowModalDestroyOldAndInitNewDatatable('#getEngineerModal','#engineerModalTable');
	$('#engineerModalTable tbody').on('click', 'input[type="checkbox"]', function () {
  		  //チェックしたデータをとる
  		var tr = $(this).closest("tr"); 
		if(this.checked) {
			tr.toggleClass('selected');		
		 } else {
			tr.removeClass('selected');
		} 
		selectedEngineers = table.rows('.selected').data();
 	});
	onShowModalDestroyOldAndInitNewDatatable('#getClientModal','#clientModalTable');
	table=$("#clientModalTable").DataTable();
  	$('#clientModalTable tbody').on('click', 'input[type="checkbox"]', function () {
		selectedClient = null;
  		  //一つチェクスボックスだけチェックできるようにする
  		$('input[type="checkbox"]').not(this).prop('checked', false); 	  	
  		  //チェックしたデータをとる
  		 if(this.checked) {
  			var tr = $(this).closest("tr");
	  	  	selectedClient = $("#clientModalTable").DataTable().rows(tr).data()[0];	
		 }
 	});
	initalizeDatatable('#engineerListTable');
	
	/*
	*保存確認子画面の「はい」ボタンをクリックすると、submit処理
	*
	*/
	$('#modalSubmitBtn').click(function(e) {
		e.preventDefault();
		submitForm();
	});
	
	
	/*
	*更新内容を保存ボタンにクリック処理
	*
	*/
	$('#submitBtn').click(function(e) {
		e.preventDefault(); 
		$("#confirmModalContent").html("変更内容を保存しますか");
	    $('#confirmModal').modal("show");
	})
	$('#submitRegisterBtn').click(function() {
		submitForm();
	})
	//営業手数料計算処理
	calc();
});
		  	
/* apTaxSection value = 1->税別
apTaxSection value = 2->税込 */
function getTax() {
	apTaxSection=$("#apTaxSection").val();
	if (apTaxSection == 2) {
		$('#apTaxSection1').text( "税込");
	  	$('#apTaxSection2').text("税込");
	} else {
		$('#apTaxSection1').text("税別");
	  	$('#apTaxSection2').text("税別");
	}
}
/*案件の検索処理
*
*/	  	
function searchProposition() {
	//url = "http://localhost:8080/ajax/proposition/search";
	url = "/ajax/proposition/search"
	params = {
			"propositionName": $("#mdPropositionName").val(),
			"workStartDate": $("#mdWorkStartDate").val(),
			"workEndDate": $("#mdWorkEndDate").val()
	};
	$.post(url, params, function(response){
		table=$("#propositionModalTable").DataTable();
		//Datatablesに古データー削除
		//.draw() を追加すると、response がない場合（response.length ==0）、古データー削除できないエラーを解決する
		table.clear().draw(); 
		//Datatablesに新データー追加
		$.each(response, function(index, proposition){
			//add row to Datatables
			 table.row.add( [
				'<input type="checkbox" id="checkbox'+(index+1)+'" class="checkList">',
	            index +1,
	            proposition.propositionNo,
	            proposition.propositionName,
	            proposition.workStartDate,
	            proposition.workEndDate,
	            proposition.propositionContent,
	            proposition.commercialDistribution
	        ] ).draw(false);
		});
		
	}).fail(function(){
		alert("can not connect to the server");
	});
}
/*開発者の検索処理
*
*/	  	 
function searchEngineer() {
	table=$("#engineerModalTable").DataTable();
	url = "/ajax/engineer/search";
	params = {
		"engineerName" : $("#mdEngEngineerName").val(),
		"companyName" : $("#mdEngCompanyName").val(),
		"companyPersonnel" : $("#mdEngCompanyPersonnel").val() 
	};
	$.post(url, params, function(response){
		table.clear().draw();
		$.each(response, function(index, engineer){
			table.row.add( [
				'<input type="checkbox" id="checkboxEng'+(index+1)+'" class="checkListEngineer">',
	            index +1,
	            engineer.engineerId,
				engineer.engineerName,
				engineer.companyName,
				engineer.companyPersonnel,
	        ] ).draw(false);	
		});
		
	}).fail(function(){
		alert("can not connect to the server");
	});
}
/*取引先情報の検索処理
*
*/		  	
function searchClient() {
	table=$("#clientModalTable").DataTable();
	url = "/ajax/client/search";
	params = {
		"clientName" : $("#mdClientName").val(),
		"clientPersonnelDepartmentName" : $("#mdClientDepartmentName").val(),
		"clientPersonnelName" : $("#mdClientPersonnelName").val() 
	};
	$.post(url, params, function(response){
		table.clear().draw();
		$.each(response, function(index, client){
			table.row.add( [
				'<input type="checkbox" id="checkboxClient'+(index+1)+'" class="checkListClient">',
	            index +1,
	            client.clientName,
				client.clientPersonnelDepartmentName,
				client.clientPersonnelPosition,
				client.clientPersonnelName,
				client.clientAddress,
				client.clientTel,
				client.clientFax,
				client.clientMail,
				client.clientId.clientCd,
				client.clientId.clientPersonnelDepartmentCd,
	        ] ).draw(false); 	
		});
		
	}).fail(function(){
		alert("can not connect to the server");
	});
}

/*
*Modalを表示されるたびに、古テーブルを破壊して、新テーブルを新規追加する。
*/
function onShowModalDestroyOldAndInitNewDatatable(modalId, datatableId) {
	$(modalId).on('shown.bs.modal', function () {	
	/* 「DataTables warning: Cannot reinitialise DataTable.For more.. 」エラー解決３ステップ
	*/
	//ステップ１：存在されてるなら、古テーブルを破壊する
	if ( $.fn.DataTable.isDataTable(datatableId) ) {
		$(datatableId).DataTable().destroy();
	}
	//ステップ２：テーブルのtbodyを空にする
	datatableBody = datatableId.concat(' tbody');
	$(datatableBody).empty();
	//ステップ3：テーブルの新規追加
	switch(datatableId) {
		 case "#propositionModalTable":
			$('#propositionModalTableThead').hide();
		     tableOption = {
				scrollY:        "200px",
				scrollCollapse: true,
				paging:         false,
				searching: 		false,
				"bInfo" : 		false,
				language : {
		            "zeroRecords": " "             
		        },
				"aoColumnDefs": [
		            { "bVisible": false, "aTargets": [ 6,7 ] },
					{ "width": "3%", "targets": 0 },
		   			{ "width": "3%", "targets": 1 },
					{ "width": "20%", "targets": 2 },

		        ],
		 	}
		    break;
		 case "#engineerModalTable":
			$('#engineerModalTableThead').hide();
		     tableOption = {
				scrollY:        "200px",
				scrollCollapse: true,
				paging:         false,
				searching: 		false,
				"bInfo" : 		false,
				language : {
		            "zeroRecords": " "             
		        },
				"columnDefs": [
		   			 { "width": "5%", "targets": 0 },
		   			 { "width": "5%", "targets": 1 },
					 { "width": "15%", "targets": 2 },
					 { "width": "15%", "targets": 3 },
					 { "width": "30%", "targets": 4 },
					 { "width": "30%", "targets": 5 },
		  		]
		 	}
		    break;
		case "#clientModalTable":
			$('#clientModalTableThead').hide();
		     tableOption = {
				scrollY:        "200px",
				scrollCollapse: true,
				paging:         false,
				searching: 		false,
				"bInfo" : 		false,
				language : {
		            "zeroRecords": " "             
		        },
				"aoColumnDefs": [
					{"bVisible": false, "aTargets": [ 6,7,8,9,10,11 ]}, 
					{ "width": "5%", "targets": 0 },
		   			 { "width": "5%", "targets": 1 },
				],
		 	}
		    break;	
		 default:
		    tableOption = {
				scrollY:        "200px",
				scrollCollapse: true,
				paging:         false,
				searching: 		false,
				"bInfo" : 		false,
				language : {
		            "zeroRecords": " "             
		        },
		 	}
	}
	 var table = $(datatableId).DataTable(tableOption);
	 table.draw(); 
	})
}

/*
*Datatablesの新規作成
*/
function initalizeDatatable(datatableId) {
	//存在してる場合、破壊
	if ( $.fn.DataTable.isDataTable(datatableId) ) {
		$(datatableId).DataTable().destroy();
	}
	table=$(datatableId).DataTable({
		scrollY:        "200px",
		scrollCollapse: true,
		paging:         false,
		searching: 		false,
		"bInfo" : 		false,
		 language : {
            "zeroRecords": " "             
        },
		"columnDefs": [
   			 { "width": "3%", "targets": 0 },
   			 { "width": "15%", "targets": 1 },
  		]
	});
}
/*取引先情報を自動的に追加する処理
*
*/
function autoFillClientInfo(selectedClient) {
	$("#clientName").val(selectedClient[2]).text(selectedClient[2]);
	$("#contractClientPersonnelDepartmentName").val(selectedClient[3]).text(selectedClient[3]);
	$("#contractClientPersonnelPosition").val(selectedClient[4]).text(selectedClient[4]); 
	$("#contractClientPersonnelName").val(selectedClient[5]).text(selectedClient[5]);
	$("#contractClientAddress").val(selectedClient[6]).text(selectedClient[6]);
	$("#contractClientTel").val(selectedClient[7]).text(selectedClient[7]);
	$("#contractClientFax").val(selectedClient[8]).text(selectedClient[8]);
	$("#contractClientMail").val(selectedClient[9]).text(selectedClient[9]);
	$("#clientCd").val(selectedClient[10]).text(selectedClient[10]);
	$("#contractClientPersonnelDepartmentCd").val(selectedClient[11]).text(selectedClient[11]);
	$("#billingName").val(selectedClient[2]).text(selectedClient[2]);
	$("#billingDepartmentName").val(selectedClient[3]).text(selectedClient[3]);
	$("#billingPersonnelPosition").val(selectedClient[4]).text(selectedClient[4]);
	$("#billingPersonnelName").val(selectedClient[5]).text(selectedClient[5]);
	$("#billingAddress").val(selectedClient[6]).text(selectedClient[6]);
	$("#billingTel").val(selectedClient[7]).text(selectedClient[7]);
	$("#billingFax").val(selectedClient[8]).text(selectedClient[8]);
	$("#billingMail").val(selectedClient[9]).text(selectedClient[9]);
	$("#billingCd").val(selectedClient[10]).text(selectedClient[10]);
	$("#billingDepartmentCd").val(selectedClient[11]).text(selectedClient[11]);	
};
//帳票サブミットする
function submitForm() {	
	var myTable = $("#engineerListTable").DataTable();
	var engineerList = myTable.rows().data();
	listEngineer = [];
	$.each(engineerList, function(index,engineer) {
		listEngineer.push(engineer[1]);	
	})
	//洗濯したエンジニアデータをFormに追加する
   $("<input />").attr("type", "hidden")
   .attr("name", "listEngineer")
   .attr("value", listEngineer)
   .appendTo("#mainForm");
	$('#mainForm').submit();
}
//帳票の入力データ削除
function clearForm(form) {
	if (form == "contractSearchForm") {
		document.getElementById( "contractNo" ).value = "" ;
    	document.getElementById( "propositionName" ).value = "" ;
    	document.getElementById( "contractClientName" ).value = "" ;
    	document.getElementById( "contractStartDateFrom" ).value = "" ;
    	document.getElementById( "contractStartDateTo" ).value = "" ;
    	document.getElementById( "contractEndDateFrom" ).value = "" ;
		document.getElementById( "contractEndDateTo" ).value = "" ;
	} else {
		$('#'+form).trigger("reset");	
	}	 
 }
//検索画面
 //契約詳細画面に移動する		  	
function redirectPost(contractNo,versionNo, url) {
	var form = document.createElement('form');	
	document.body.appendChild(form);
	form.method = 'post';
	form.action = url;
	
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = "contractNo";
	input.value = contractNo;
	form.appendChild(input);
	
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = "versionNo";
	input.value = versionNo;
	form.appendChild(input); 
	form.submit();
}  		
//詳細画面
//ボタンをクリックしたら、redirect処理
function redirect(url) {
	var form = document.createElement('form');
    document.body.appendChild(form);
    form.method = 'get';
    form.action = url;
    form.submit();
}
//詳細画面の編集ボタンのクリック処理
function update(contractNo,versionNo,url) {
	var form = document.createElement('form');	
	document.body.appendChild(form);
	form.method = 'post';
	form.action = url;
	
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = "contractNo";
	input.value = contractNo;
	form.appendChild(input);
	
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = "versionNo";
	input.value = versionNo;
	form.appendChild(input); 
	form.submit();
} 
/*
*営業手数料計算
*/
function calc() {
	//売掛金額
	let ar = 0;
	//買掛金額
	let ap = 0;
	$(".calc-class").on("change", () => {
		ar = getValue("arRangeUnitPrice", "arFixedUnitPrice","arTimeUnitPrice");
		ap = getValue("apRangeUnitPrice", "apFixedUnitPrice","apTimeUnitPrice");
		updateValue(ar,ap);
	})
	$("#saleCommission").on("change", () => {
		ar = getValue("arRangeUnitPrice", "arFixedUnitPrice","arTimeUnitPrice");
		ap = getValue("apRangeUnitPrice", "apFixedUnitPrice","apTimeUnitPrice");
		updateValue(ar,ap);
	})
}
/*
*営業利益、営業利益率項目に値追加
*/
function updateValue(ar,ap) {
	 saleCommission = Number($("#saleCommission").val());
	if (saleCommission == "NaN") {
		alert("粗利率に数字を入力してください。");
	} else {
		//営業利益
		operatingIncome = (ar -ap)*saleCommission*0.01;
		//営業利益率
		profitRate = operatingIncome/ar *100;
		document.getElementById("operatingIncome").value = operatingIncome.toFixed(0);
		document.getElementById("profitRate").value = profitRate.toFixed(2) ;
	}
}

/*
*範囲単価、固定単価、時間単価から値を取得する
*/ 
function getValue(a1, a2, a3){
	value1 = Number($("#"+a1).val());
	value2 = Number($("#"+a2).val());
	value3 = Number($("#"+a3).val());
	if (value1 != "NaN" && $("#"+a1).val()!="") {
		return value1;
	}
	if (value2 != "NaN" && $("#"+a2).val()!="") {
		return value2;
	}
	if (value3 != "NaN" && $("#"+a3).val()!="") {
		 //時間単価で160をかける
		return value3 * 160;
	} 	
	return 0;
}

 