/*
*日付を過去に設定できないようにする
*/
	$(function datetimeExmin() {
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		var hours = dtToday.getHours();
		var minutes = dtToday.getMinutes();
		if (month < 10)
			month = '0' + month.toString();
		if (day < 10)
			day = '0' + day.toString();

		document.getElementById("taskStartDate").min = year + '-' + month + '-'
				+ day + 'T' + hours + ':' + minutes;
		document.getElementById("taskFinishDate").min = year + '-' + month
				+ '-' + day + 'T' + hours + ':' + minutes;
	});

$(function datetimeExvalue() {
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		var hours = dtToday.getHours();
		var minutes = dtToday.getMinutes();
		if (month < 10)
			month = '0' + month.toString();
		if (day < 10)
			day = '0' + day.toString();

		document.getElementById("taskStartDate").value = year + '-' + month
				+ '-' + day + 'T' + hours + ':' + minutes;
		document.getElementById("taskFinishDate").value = year + '-' + month
				+ '-' + day + 'T' + hours + ':' + minutes;
	});

	
