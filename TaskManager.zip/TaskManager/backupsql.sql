CREATE SCHEMA `taskmanagerdb` DEFAULT CHARACTER SET utf8 ;

CREATE TABLE `taskmanagerdb`.`task` (
  `task_id` VARCHAR(11) INT NOT NULL,
  `task_title` VARCHAR(45) NOT NULL,
  `task_kana` VARCHAR(45) NULL,
  `task_member` VARCHAR(20) NOT NULL,
  `task_member_kana` VARCHAR(20) NULL,
  `task_start_date` VARCHAR(21) NOT NULL,
  `task_finish_date` VARCHAR(21) NULL,
  `task_priority` VARCHAR(12) NOT NULL,
  `task_progress` VARCHAR(6) NULL,
  `task_detail` VARCHAR(50) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE user(
    user_id INT AUTO_INCREMENT,
    user_name VARCHAR(255),
    password VARCHAR(255),
    PRIMARY KEY(user_id)
);

INSERT INTO user (user_name, password) VALUES
('user','password'),('pompom','purin');
