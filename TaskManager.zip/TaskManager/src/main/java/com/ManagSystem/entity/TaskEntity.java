package com.ManagSystem.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "task")
public class TaskEntity {

	@Id
	private String taskId;

	private String taskTitle;

	private String taskKana;

	private String taskMember;

	private String taskMemberKana;

	private String taskStartDate;
	
	private String taskFinishDate;

	private String taskPriority;
	
	private String taskProgress;

	private String taskDetail;

}
