package com.ManagSystem.form;

import lombok.Data;

@Data
public class TaskDetailForm {
	
	private String taskId;

	private String taskTitle;

	private String taskKana;

	private String taskMember;

	private String taskMemberKana;

	private String taskStartDate;
	
	private String taskFinishDate;

	private String taskPriority;
	
	private String taskProgress;

	private String taskDetail;

}
