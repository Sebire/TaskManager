package com.ManagSystem.form;

import java.time.LocalDateTime;

import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class TaskRegisterForm {

	private String taskId;
	
	@NotEmpty(message = "タスク名を入力して下さい")
	private String taskTitle;
	
	private String taskKana;
	
	@NotEmpty(message = "担当者名を入力して下さい")
	private String taskMember;
	
	private String taskMemberKana;
	
	@NotEmpty(message = "日時を入力して下さい")
    private String taskStartDate;
	
	private String taskFinishDate;
	
	private String taskPriority;
	
	private String taskProgress;
	
	private String taskDetail;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	private LocalDateTime datetime;
	
}
