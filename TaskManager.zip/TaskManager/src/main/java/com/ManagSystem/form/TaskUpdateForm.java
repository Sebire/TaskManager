package com.ManagSystem.form;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class TaskUpdateForm {

	private String taskId;

	@NotEmpty(message = "タスク名を入力して下さい")
	private String taskTitle;

	private String taskKana;

	@NotEmpty(message = "担当者名を入力して下さい")
	private String taskMember;

	private String taskMemberKana;

	@NotEmpty(message = "日付を入力して下さい")
	private String taskStartDate;
	
	private String taskFinishDate;

	private String taskPriority;

	private String taskProgress;

	private String taskDetail;
}
