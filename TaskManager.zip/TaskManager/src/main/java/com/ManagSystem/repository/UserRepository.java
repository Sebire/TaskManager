package com.ManagSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ManagSystem.entity.LoginEntity;

@Repository
public interface UserRepository extends JpaRepository<LoginEntity, Integer>{

}
