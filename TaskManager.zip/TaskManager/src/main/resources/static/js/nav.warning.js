/**
 * ページを離れる際に警告を出す。
 */
 var is_note_msg=true;
window.onbeforeunload = function(event){
  if(is_note_msg){
    event = event || window.event; 
    event.returnValue = '入力中のページから移動しますか？';
  }
}