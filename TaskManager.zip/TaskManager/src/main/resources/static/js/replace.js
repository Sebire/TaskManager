/**
 * 日時のTを消す
 */
 $(function sdateReplace(){
	$('.sdate').each(function(){
		var txt = $(this).text();
		$(this).text(
			txt.replace(/T/g," ")
		);
	});
});
window.onload = sdateReplace;