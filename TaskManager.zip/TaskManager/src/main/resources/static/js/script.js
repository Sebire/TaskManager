$(document).ready(function () {
    $("#entry_date").val(moment(new Date()).format('YYYY-MM-DD'));
    $("#negotiation_date").val(moment(new Date()).format('YYYY-MM-DD'));
    $("#start_date").val(moment(new Date()).format('YYYY-MM-DD'));
    $("#end_date").val(moment(new Date(addDaysWRONG(new Date(), 10))).format('YYYY-MM-DD'));

    let a = $("#number_a")
    let b = $("#number_b")
    let c = $("#number_c")
    let d = $("#number_d")

    let d_nd = $("#number_d_nd")
    let a_nd = $("#number_a_nd")
    let d1 = $("#number_d1")

    a.on("change", () => {
        if (b.val() && c.val()){
            let value = (a.val() - b.val()) * c.val() / 100
            d.val(Number.isInteger(value) ? value : value.toFixed(2));
            
            d_nd.val(d.val());
            a_nd.val(a.val());

            let value_1 = d.val() / a.val() * 100;
            d1.val(Number.isInteger(value_1) ? value_1 : value_1.toFixed(2))
        }
    })
    b.on("change", () => {
        if (a.val() && c.val()){
            let value = (a.val() - b.val()) * c.val() / 100
            d.val(Number.isInteger(value) ? value : value.toFixed(2));
            
            d_nd.val(d.val());
            a_nd.val(a.val());

            let value_1 = d.val() / a.val() * 100;
            d1.val(Number.isInteger(value_1) ? value_1 : value_1.toFixed(2))
        }
    })
    c.on("change", () => {
        if (b.val() && a.val()){
            let value = (a.val() - b.val()) * c.val() / 100
            d.val(Number.isInteger(value) ? value : value.toFixed(2));
            
            d_nd.val(d.val());
            a_nd.val(a.val());

            let value_1 = d.val() / a.val() * 100;
            d1.val(Number.isInteger(value_1) ? value_1 : value_1.toFixed(2))
        }
    })

    $("#profit_save").on("click", () => {
        const data = {
            d: d.val(),
            d1: d1.val(),
        }
        alert(JSON.stringify(data))
    })

    //Task
    $("#info-task_update").on('click', () => {
        let select_task = $("#info-task_select").val();
        if (select_task == 1) { 
            $.getJSON('/js/json.json', (data) => {
                const task = data.task;
                $("#info-task_title").val(task.title);
                $("#info-task_priority").val(task.priority);
                $("#info-task_datetime").val(task.datetime);
                $("#info-task_limitdatetime").val(task.limitdatetime);
                $("#info-task_detail").val(task.detail);
            })
        }
    })

    $("#info-task_save").on('click', () => {
        const title = $("#info-task_title").val();
        const priority = $("#info-task_priority").val();
        const datetime = $("#info-task_datetime").val();
        const limitdatetime = $("#info-task_limitdatetime").val();
        const detail = $("#info-task_detail").val();

        alert(JSON.stringify({
            title,
            priority,
            datetime,
            limitdatetime,
            detail,
        }))
    })

    

    $("#menu_bar").on('click', () => {
        var x = document.getElementById("myLinks");
        if (x.style.display === "block") {
            x.style.display = "none";
        } else {
            x.style.display = "block";
        }
    })
    
    $("#user_info").on('click', () => {
        $("#user_info_ul").css({
            "position": "fixed", 
            "margin": "0px",
            "right": "-50px",
            "top": "0",
            "width": "200px",
            "transform": "translate(-61px, 37px)",
            "display": "block"
        })
    })

    $("#dropdown_menu").on('click', () => {
        var x = document.getElementById("dropdown_list");
        if (x.style.display === "block") {
            x.style.display = "none";
        } else {
            x.style.display = "block";
        }
    })

    $(document).on('click', function (e) {
        if ($(e.target).closest("#dropdown_menu").length === 0) {
            $("#dropdown_list").hide();
        }
        if ($(e.target).closest("#menu_bar").length === 0) {
            $("#myLinks").hide();
        }
        if ($(e.target).closest("#user_info").length === 0) {
            $("#user_info_ul").hide();
        }
    });

    $(window).on('scroll', () => {
        $("#myLinks").hide();
        $("#user_info_ul").hide();
    })

    $("#dropdown_list button").on('click', () => {
        $("#dropdown_list").css({"display": "none"})
    })

    

    function addDaysWRONG(date, days) {
        var result = new Date();
        result.setDate(date.getDate() + days);
        return result;
    }

	$('#dtBasicExample').DataTable({
    	"paging": true // false to disable pagination (or any other option)
  	});
  	$('.dataTables_length').addClass('bs-select');

});