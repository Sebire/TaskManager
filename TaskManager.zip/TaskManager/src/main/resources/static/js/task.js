$(document).ready(function() {
	// 入力項目フォーカス時のEnterキーによるSubmitを無効
	$('input').keypress(function(ev) {
		if ((ev.which && ev.which === 13) || (ev.keyCode && ev.keyCode === 13)) {
			return false;
		} else {
			return true;
		}
	});
	
	// Datables日本語にする
	$.extend( $.fn.dataTable.defaults, {
		language: {
			url: "../../assets/plugins/datatables.net/datatables-japanese.json"
		}
	});
	// Datables指定する
	$("#datatable-list-task").DataTable({
		// 検索機能 無効
		searching: false
	});
});
/**
 * 検索項目クリア処理
 */
function clearForm() {
	document.getElementById("taskTitle").value = "";
	document.getElementById("taskMember").value = "";
}

/**
 * 詳細画面遷移処理
 */
function redirectPost(data,url) {
	var form = document.createElement('form');	
	document.body.appendChild(form);
	form.method = 'post';
	form.action = url;
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = "taskId";
	input.value = data;
	form.appendChild(input);
	form.submit();  
}

/**
 * 登録ボタン押下
 */
function registerConfirm(){
	$('#registerbtn').val();
}

/**
 * 変更ボタン押下
 */
function updateConfirm(){
	$('#updatebtn').val();
}

/**
 * 削除ボタン押下
 */
function deleteConfirm(){
	$('#deletebtn').val();
}

$(function autoKana() {
$.fn.autoKana('#title', '#kana');
$.fn.autoKana('#uname', '#ukana');
})
